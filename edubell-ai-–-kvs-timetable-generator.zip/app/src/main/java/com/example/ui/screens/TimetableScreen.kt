package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimetableSlotEntity
import com.example.ui.theme.*
import com.example.viewmodel.EduBellViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    viewModel: EduBellViewModel
) {
    val classes by viewModel.classes.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val timetableSlots by viewModel.timetableSlots.collectAsState()
    val periods by viewModel.periods.collectAsState()

    var viewMode by remember { mutableIntStateOf(0) } // 0 = Class-Wise, 1 = Teacher-Wise
    var selectedClassIndex by remember { mutableIntStateOf(0) }
    var selectedTeacherIndex by remember { mutableIntStateOf(0) }
    var selectedDay by remember { mutableStateOf("MONDAY") }

    var showExportDialog by remember { mutableStateOf(false) }

    val days = listOf("MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY")

    val selectedClass = classes.getOrNull(selectedClassIndex)
    val selectedTeacher = teachers.getOrNull(selectedTeacherIndex)

    // Filter slots based on view mode and selection
    val filteredSlots = remember(viewMode, selectedClassIndex, selectedTeacherIndex, selectedDay, timetableSlots) {
        timetableSlots.filter { slot ->
            val dayMatches = slot.dayOfWeek == selectedDay
            if (viewMode == 0) {
                dayMatches && selectedClass != null && slot.className == selectedClass.className && slot.section == selectedClass.section
            } else {
                dayMatches && selectedTeacher != null && slot.teacherName == selectedTeacher.name
            }
        }.sortedBy { it.periodNo }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("KVS Primary Timetable Grid", color = Color.White, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showExportDialog = true }) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "Export PDF", tint = Color.White)
                    }
                    IconButton(onClick = { viewModel.generateTimetableWithAi() }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Regenerate", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KvsNavyPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // View Mode Selector Tabs
            TabRow(
                selectedTabIndex = viewMode,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = KvsNavyPrimary
            ) {
                Tab(
                    selected = viewMode == 0,
                    onClick = { viewMode = 0 },
                    text = { Text("Class-Wise View", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = viewMode == 1,
                    onClick = { viewMode = 1 },
                    text = { Text("Teacher-Wise View", fontWeight = FontWeight.Bold) }
                )
            }

            // Entity Selection Chips Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(vertical = 8.dp)
            ) {
                if (viewMode == 0 && classes.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(classes.size) { idx ->
                            val cls = classes[idx]
                            FilterChip(
                                selected = selectedClassIndex == idx,
                                onClick = { selectedClassIndex = idx },
                                label = { Text("${cls.className} - ${cls.section}") },
                                leadingIcon = if (selectedClassIndex == idx) {
                                    { Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null
                            )
                        }
                    }
                } else if (viewMode == 1 && teachers.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(teachers.size) { idx ->
                            val teacher = teachers[idx]
                            FilterChip(
                                selected = selectedTeacherIndex == idx,
                                onClick = { selectedTeacherIndex = idx },
                                label = { Text(teacher.name) },
                                leadingIcon = if (selectedTeacherIndex == idx) {
                                    { Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Day Selector Chips
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(days) { day ->
                        val isSelected = selectedDay == day
                        AssistChip(
                            onClick = { selectedDay = day },
                            label = { Text(day, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = if (isSelected) KvsNavyPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Divider()

            // Header Summary Info
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (viewMode == 0) "${selectedClass?.className ?: "Class"} - ${selectedClass?.section ?: "A"} Schedule ($selectedDay)" else "${selectedTeacher?.name ?: "Teacher"} Schedule ($selectedDay)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Surface(color = KvsGoldAccent.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                    Text(
                        text = "8 Periods",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = KvsGoldAccent)
                    )
                }
            }

            // Slots Timeline List
            if (filteredSlots.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Outlined.EventBusy, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No timetable slots found for this selection.", color = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.generateTimetableWithAi() }) {
                            Text("Click to Generate Timetable")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredSlots) { slot ->
                        TimetableSlotCard(slot = slot, periods = periods)
                    }
                }
            }
        }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Export KVS Primary Timetable") },
            text = {
                Column {
                    Text("Select export format for official KVS primary school distribution:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            viewModel.addNotification("Export PDF", "Generated Printable Class Timetable PDF", "SUCCESS")
                            showExportDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Class-Wise Printable PDF")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            viewModel.addNotification("Export CSV", "Exported Teacher Master & Workload CSV", "SUCCESS")
                            showExportDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.TableChart, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Teacher Schedule CSV")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun TimetableSlotCard(
    slot: TimetableSlotEntity,
    periods: List<com.example.data.local.PeriodMasterEntity>
) {
    val periodInfo = periods.find { it.periodNo == slot.periodNo }
    val timeRange = if (periodInfo != null) "${periodInfo.startTime} - ${periodInfo.endTime}" else "Period ${slot.periodNo}"

    val subjectColor = when {
        slot.periodNo == 0 -> Color(0xFF6366F1) // Assembly Indigo
        slot.periodNo == 5 -> Color(0xFF059669) // Lunch Green
        slot.subjectName.contains("Hindi") -> SubjectHindiColor
        slot.subjectName.contains("English") -> SubjectEnglishColor
        slot.subjectName.contains("Math") -> SubjectMathsColor
        slot.subjectName.contains("EVS") -> SubjectEvsColor
        slot.subjectName.contains("Art") -> SubjectArtColor
        slot.subjectName.contains("Music") -> SubjectMusicColor
        slot.subjectName.contains("Games") -> SubjectGamesColor
        slot.subjectName.contains("Library") -> SubjectLibraryColor
        slot.subjectName.contains("Digital") || slot.subjectName.contains("CMP") -> SubjectCompColor
        else -> KvsNavyPrimary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (slot.isConflict) 2.dp else 0.dp,
                color = if (slot.isConflict) Color.Red else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (slot.isFixed) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Period Number Badge
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(subjectColor.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (slot.periodNo == 0) "ASM" else if (slot.periodNo == 5) "LCH" else "P${slot.periodNo}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = subjectColor
                    )
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = slot.subjectName,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (slot.isFixed) KvsNavyPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    )

                    if (slot.isConflict) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(color = Color.Red, shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "CLASH",
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 9.sp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = slot.teacherName,
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Icon(imageVector = Icons.Default.MeetingRoom, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = slot.roomName,
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = subjectColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = timeRange,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = subjectColor
                        )
                    )
                }
            }
        }
    }
}
