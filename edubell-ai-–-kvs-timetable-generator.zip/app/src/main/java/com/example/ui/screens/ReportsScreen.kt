package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.KvsNavyPrimary
import com.example.viewmodel.EduBellViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: EduBellViewModel
) {
    val teachers by viewModel.teachers.collectAsState()
    val classes by viewModel.classes.collectAsState()
    val timetableSlots by viewModel.timetableSlots.collectAsState()
    val substitutions by viewModel.substitutions.collectAsState()

    var selectedReport by remember { mutableIntStateOf(0) }

    val reportTypes = listOf(
        "Teacher Workload Report",
        "Free Periods Report",
        "Substitution Arrangement Log",
        "KVS Compliance Summary"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("KVS Timetable Reports & Analytics", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KvsNavyPrimary)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedReport,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = KvsNavyPrimary,
                edgePadding = 16.dp
            ) {
                reportTypes.forEachIndexed { idx, title ->
                    Tab(
                        selected = selectedReport == idx,
                        onClick = { selectedReport = idx },
                        text = { Text(title, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedReport) {
                    0 -> {
                        item {
                            Text("PRT Teacher Workload Distribution", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        items(teachers) { teacher ->
                            val assignedCount = timetableSlots.count { it.teacherName == teacher.name }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(teacher.name, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                        Surface(
                                            color = if (assignedCount <= teacher.maxWeeklyPeriods) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "$assignedCount / ${teacher.maxWeeklyPeriods} Periods/Wk",
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        progress = { (assignedCount.toFloat() / teacher.maxWeeklyPeriods.toFloat()).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(6.dp),
                                        color = KvsNavyPrimary
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        item {
                            Text("Free Period Availability Matrix", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        items((1..8).toList()) { pNo ->
                            val busyTeachers = timetableSlots.filter { it.periodNo == pNo && it.dayOfWeek == "MONDAY" }.map { it.teacherName }.toSet()
                            val freeTeachers = teachers.filter { !busyTeachers.contains(it.name) && !it.isAbsentToday }

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("Period $pNo - Free Teachers (${freeTeachers.size})", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (freeTeachers.isEmpty()) "No free PRT teachers" else freeTeachers.joinToString(", ") { it.name },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    2 -> {
                        item {
                            Text("Daily Teacher Substitution Log", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        if (substitutions.isEmpty()) {
                            item { Text("No substitutions assigned today.") }
                        } else {
                            items(substitutions) { sub ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("Period ${sub.periodNo} • ${sub.className}-${sub.section}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                        Text("Absent: ${sub.absentTeacherName} → Substitute: ${sub.substituteTeacherName}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("KVS Guideline Compliance Rating: 100%", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("✔ Morning Assembly fixed as Period 0 for all classes")
                                    Text("✔ Recess / Lunch fixed as Period 5")
                                    Text("✔ Hindi, English, Maths allocated 6 periods/week")
                                    Text("✔ EVS / CLA allocated 5 periods/week")
                                    Text("✔ Co-curriculars (Music, Art, Games) allocated 3 periods/week each")
                                    Text("✔ Zero teacher double-booking clashes")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
