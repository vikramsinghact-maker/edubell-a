package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.UploadDocEntity
import com.example.ui.theme.KvsNavyPrimary
import com.example.viewmodel.EduBellViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadCenterScreen(
    viewModel: EduBellViewModel,
    onNavigateToTimetable: () -> Unit
) {
    val uploadDocs by viewModel.uploadDocs.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var showPresetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Upload Center & Guidelines AI", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KvsNavyPrimary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Preset Loader Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Official KVS Primary Preset",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Pre-load official Classes I-V, PRT teachers, subject allocation & bell schedule with 1-click.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.seedDefaultKvsData() },
                            colors = ButtonDefaults.buttonColors(containerColor = KvsNavyPrimary)
                        ) {
                            Text("Load Preset")
                        }
                    }
                }
            }

            // Upload Cards Grid
            item {
                Text(
                    text = "Upload Documents & Excel Files",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    UploadCardItem(
                        title = "KVS Guideline PDF",
                        desc = "Extract weekly periods, lunch timing, PRT workload constraints",
                        icon = Icons.Outlined.PictureAsPdf,
                        color = Color(0xFFE11D48),
                        onUploadClick = {
                            viewModel.handleSimulatedDocUpload(
                                docName = "KVS_Primary_Schedule_Guidelines.pdf",
                                docType = "KVS_GUIDELINE",
                                fileContent = "KVS Primary Timetable Guidelines: 36 periods/week, 8 periods daily, 6 Hindi, 6 English, 6 Maths, 5 EVS, 3 Art, 3 Music, 3 Games, 1 Library, 2 CMP, 1 Work Edu."
                            )
                        }
                    )

                    UploadCardItem(
                        title = "Teachers Excel / CSV",
                        desc = "Upload list of PRTs, Employee IDs, primary subjects & load limits",
                        icon = Icons.Outlined.TableChart,
                        color = Color(0xFF2563EB),
                        onUploadClick = {
                            viewModel.handleSimulatedDocUpload(
                                docName = "PRT_Teachers_List_2026.csv",
                                docType = "TEACHER_EXCEL",
                                fileContent = "Name,EmpID,Designation,Subject\nMrs. Sunita Verma,KVS-PRT-001,Headmaster,Hindi\nMr. Rahul Sharma,KVS-PRT-002,PRT,Mathematics\nMs. Priya Singh,KVS-PRT-003,PRT,English"
                            )
                        }
                    )

                    UploadCardItem(
                        title = "Classes & Sections Excel",
                        desc = "Upload Class I to V section mappings & room numbers",
                        icon = Icons.Outlined.Class,
                        color = Color(0xFF059669),
                        onUploadClick = {
                            viewModel.handleSimulatedDocUpload(
                                docName = "Classes_Rooms_2026.xlsx",
                                docType = "CLASS_EXCEL",
                                fileContent = "Class I-A, Class I-B, Class II-A, Class II-B, Class III-A, Class III-B, Class IV-A, Class IV-B, Class V-A, Class V-B"
                            )
                        }
                    )

                    UploadCardItem(
                        title = "Bell Timing & Period Schedule",
                        desc = "Upload shift timings, assembly time, recess break",
                        icon = Icons.Outlined.AccessTime,
                        color = Color(0xFFD97706),
                        onUploadClick = {
                            viewModel.handleSimulatedDocUpload(
                                docName = "KVS_Bell_Timing_Single_Shift.csv",
                                docType = "BELL_EXCEL",
                                fileContent = "Assembly: 07:30-08:00, P1: 08:00-08:40, P2: 08:40-09:20, Recess: 10:40-11:10"
                            )
                        }
                    )
                }
            }

            // Processed Documents List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Processed Files & AI Rules Extracted",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = "${uploadDocs.size} Files",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            if (uploadDocs.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("No uploaded documents yet. Click above to upload or pre-load preset.")
                        }
                    }
                }
            } else {
                items(uploadDocs) { doc ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF059669)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = doc.docName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = doc.uploadDate,
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "AI Extracted Rules: ${doc.summaryText}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        viewModel.generateTimetableWithAi()
                        onNavigateToTimetable()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KvsNavyPrimary)
                ) {
                    Icon(imageVector = Icons.Default.FlashOn, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Timetable From Uploaded Data", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
fun UploadCardItem(
    title: String,
    desc: String,
    icon: ImageVector,
    color: Color,
    onUploadClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onUploadClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(color.copy(alpha = 0.1f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                )
            }

            IconButton(onClick = onUploadClick) {
                Icon(imageVector = Icons.Default.FileUpload, contentDescription = "Upload", tint = color)
            }
        }
    }
}
