package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KVS Brand Colors - Navy Blue, Vibrant Action Blue, Gold Accent, Clean Light Slate
val KvsNavyPrimary = Color(0xFF1E3A8A) // KVS Deep Navy #1E3A8A
val KvsRoyalBlue = Color(0xFF1E40AF)
val KvsSkyBlue = Color(0xFF2563EB)   // Vibrant Action Blue #2563EB
val KvsGoldAccent = Color(0xFFD97706) // KVS Gold / Amber #D97706
val KvsLightBg = Color(0xFFF8FAFC)    // Slate 50 Light Background #F8FAFC
val KvsSurface = Color(0xFFFFFFFF)    // Crisp Pure White #FFFFFF
val KvsBorderColor = Color(0xFFE2E8F0) // Subtle Slate Border

val KvsNavyDark = Color(0xFF0F172A)
val KvsSurfaceDark = Color(0xFF1E293B)
val KvsPrimaryDark = Color(0xFF60A5FA)
val KvsSecondaryDark = Color(0xFF38BDF8)
val KvsGoldDark = Color(0xFFFBBF24)

// KVS Subject Brand Colors
val SubjectHindiColor = Color(0xFFE11D48) // Rose
val SubjectEnglishColor = Color(0xFF2563EB) // Blue
val SubjectMathsColor = Color(0xFFD97706) // Amber
val SubjectEvsColor = Color(0xFF059669) // Emerald
val SubjectArtColor = Color(0xFF7C3AED) // Violet
val SubjectMusicColor = Color(0xFFDB2777) // Pink
val SubjectGamesColor = Color(0xFF0284C7) // Sky
val SubjectLibraryColor = Color(0xFF4F46E5) // Indigo
val SubjectCompColor = Color(0xFF0D9488) // Teal
val SubjectClaColor = Color(0xFF854D0E) // Bronze


