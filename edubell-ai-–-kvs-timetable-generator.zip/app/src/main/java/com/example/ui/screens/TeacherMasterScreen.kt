package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TeacherEntity
import com.example.ui.theme.KvsNavyPrimary
import com.example.viewmodel.EduBellViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherMasterScreen(
    viewModel: EduBellViewModel
) {
    val teachers by viewModel.teachers.collectAsState()
    val substitutions by viewModel.substitutions.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedAbsentTeacher by remember { mutableStateOf<TeacherEntity?>(null) }
    var showSubstituteDialog by remember { mutableStateOf(false) }

    var filterText by remember { mutableStateOf("") }

    val filteredTeachers = teachers.filter {
        it.name.contains(filterText, ignoreCase = true) ||
        it.primarySubject.contains(filterText, ignoreCase = true) ||
        it.empId.contains(filterText, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PRT Teacher Master & Substitutions", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = KvsNavyPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = KvsNavyPrimary,
                contentColor = Color.White
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Teacher")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search & Stats Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = filterText,
                    onValueChange = { filterText = it },
                    placeholder = { Text("Search PRT teacher by name, ID or subject...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Total PRT Staff: ${teachers.size}",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Active: ${teachers.count { !it.isAbsentToday }} | Absent: ${teachers.count { it.isAbsentToday }}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (teachers.any { it.isAbsentToday }) Color(0xFFDC2626) else Color(0xFF059669),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Teacher Cards List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredTeachers) { teacher ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (teacher.isAbsentToday) Color(0xFFFEF2F2) else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .background(
                                                if (teacher.isAbsentToday) Color(0xFFFCA5A5) else KvsNavyPrimary.copy(alpha = 0.1f),
                                                CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = teacher.name.take(1),
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (teacher.isAbsentToday) Color.Red else KvsNavyPrimary
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text(
                                            text = teacher.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${teacher.empId} • ${teacher.designation}",
                                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (teacher.isAbsentToday) "Absent" else "Active",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (teacher.isAbsentToday) Color.Red else Color(0xFF059669)
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Switch(
                                        checked = teacher.isAbsentToday,
                                        onCheckedChange = { isAbsent ->
                                            viewModel.toggleTeacherAbsence(teacher.id, isAbsent)
                                            if (isAbsent) {
                                                selectedAbsentTeacher = teacher
                                                showSubstituteDialog = true
                                            }
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Primary Subject: ${teacher.primarySubject}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                                    )
                                    Text(
                                        text = "Max Load: ${teacher.maxDailyPeriods} p/day, ${teacher.maxWeeklyPeriods} p/week",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                                    )
                                }

                                if (teacher.isAbsentToday) {
                                    Button(
                                        onClick = {
                                            selectedAbsentTeacher = teacher
                                            showSubstituteDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Assign Substitute", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Teacher Dialog
    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var empId by remember { mutableStateOf("KVS-PRT-0") }
        var subject by remember { mutableStateOf("Mathematics") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add KVS PRT Teacher") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Teacher Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = empId,
                        onValueChange = { empId = it },
                        label = { Text("KVS Employee ID") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Primary Subject") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            viewModel.addTeacher(
                                TeacherEntity(
                                    name = name,
                                    empId = empId,
                                    designation = "PRT",
                                    primarySubject = subject
                                )
                            )
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Add Teacher")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Auto Substitute Finder Dialog
    if (showSubstituteDialog && selectedAbsentTeacher != null) {
        var selectedPeriod by remember { mutableIntStateOf(1) }

        AlertDialog(
            onDismissRequest = { showSubstituteDialog = false },
            title = { Text("AI Substitute Finder for ${selectedAbsentTeacher?.name}") },
            text = {
                Column {
                    Text("Select period to find an available free PRT teacher:")
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        (1..8).forEach { pNo ->
                            FilterChip(
                                selected = selectedPeriod == pNo,
                                onClick = { selectedPeriod = pNo },
                                label = { Text("P$pNo") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "EduBell AI will check free PRTs without schedule clashes and assign the best match.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val absName = selectedAbsentTeacher?.name ?: ""
                        viewModel.autoSuggestAndAssignSubstitute(
                            absentTeacherName = absName,
                            periodNo = selectedPeriod,
                            className = "Class III",
                            section = "A"
                        )
                        showSubstituteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Auto-Assign Best Free PRT")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubstituteDialog = false }) { Text("Cancel") }
            }
        )
    }
}
