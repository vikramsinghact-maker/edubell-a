package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.EduBellTheme
import com.example.ui.theme.KvsNavyPrimary
import com.example.viewmodel.EduBellViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Upload : Screen("upload", "Upload", Icons.Default.CloudUpload)
    object Timetable : Screen("timetable", "Timetable", Icons.Default.GridOn)
    object Teachers : Screen("teachers", "Teachers", Icons.Default.People)
    object Masters : Screen("masters", "Masters", Icons.Default.SettingsSuggest)
    object Assistant : Screen("assistant", "AI Chat", Icons.Default.AutoAwesome)
    object Reports : Screen("reports", "Reports", Icons.Default.Analytics)
}

class MainActivity : ComponentActivity() {

    private val viewModel: EduBellViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            EduBellTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val notifications by viewModel.notifications.collectAsState()
                val snackbarHostState = remember { SnackbarHostState() }

                // Show notification snackbar when new notification arrives
                LaunchedEffect(notifications.size) {
                    if (notifications.isNotEmpty()) {
                        val latest = notifications.first()
                        snackbarHostState.showSnackbar(
                            message = "${latest.title}: ${latest.message}",
                            duration = SnackbarDuration.Short
                        )
                    }
                }

                val bottomBarScreens = listOf(
                    Screen.Dashboard,
                    Screen.Upload,
                    Screen.Timetable,
                    Screen.Teachers,
                    Screen.Masters,
                    Screen.Assistant,
                    Screen.Reports
                )

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                        ) {
                            bottomBarScreens.forEach { screen ->
                                val selected = currentRoute == screen.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.title
                                        )
                                    },
                                    label = { Text(screen.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = KvsNavyPrimary,
                                        selectedTextColor = KvsNavyPrimary,
                                        indicatorColor = KvsNavyPrimary.copy(alpha = 0.15f)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Dashboard.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Dashboard.route) {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToUpload = { navController.navigate(Screen.Upload.route) },
                                onNavigateToTimetable = { navController.navigate(Screen.Timetable.route) },
                                onNavigateToSubstitutions = { navController.navigate(Screen.Teachers.route) },
                                onNavigateToAssistant = { navController.navigate(Screen.Assistant.route) }
                            )
                        }

                        composable(Screen.Upload.route) {
                            UploadCenterScreen(
                                viewModel = viewModel,
                                onNavigateToTimetable = { navController.navigate(Screen.Timetable.route) }
                            )
                        }

                        composable(Screen.Timetable.route) {
                            TimetableScreen(viewModel = viewModel)
                        }

                        composable(Screen.Teachers.route) {
                            TeacherMasterScreen(viewModel = viewModel)
                        }

                        composable(Screen.Masters.route) {
                            MastersScreen(viewModel = viewModel)
                        }

                        composable(Screen.Assistant.route) {
                            AiAssistantScreen(viewModel = viewModel)
                        }

                        composable(Screen.Reports.route) {
                            ReportsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
