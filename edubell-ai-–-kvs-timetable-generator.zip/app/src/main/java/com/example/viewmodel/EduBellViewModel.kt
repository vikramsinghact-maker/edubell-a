package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiChatService
import com.example.data.KvsPresetData
import com.example.data.local.*
import com.example.engine.KvsGuidelineParser
import com.example.engine.TimetableGeneratorEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "User" or "EduBell AI"
    val text: String,
    val timestamp: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
)

data class UiNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val type: String // "SUCCESS", "WARNING", "ERROR", "INFO"
)

class EduBellViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = EduBellDatabase.getDatabase(application).edubellDao()

    // Database Flows
    val schoolSettings = dao.getSchoolSettings().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val teachers = dao.getAllTeachers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activeTeachers = dao.getActiveTeachers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val classes = dao.getAllClasses().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val subjects = dao.getAllSubjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val rooms = dao.getAllRooms().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val periods = dao.getAllPeriods().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val timetableSlots = dao.getAllTimetableSlots().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val substitutions = dao.getAllSubstitutions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val uploadDocs = dao.getAllUploadDocs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Generation State
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _generationProgress = MutableStateFlow(0f)
    val generationProgress: StateFlow<Float> = _generationProgress.asStateFlow()

    private val _generationStatusText = MutableStateFlow("")
    val generationStatusText: StateFlow<String> = _generationStatusText.asStateFlow()

    // Chat Assistant State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "EduBell AI",
                text = "👋 Namaste! I am your **EduBell AI Assistant** for KVS Primary Section. I can automatically generate timetables, detect teacher clashes, assign absent teacher substitutes, and export reports. How can I assist you today?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // Notifications Flow
    private val _notifications = MutableStateFlow<List<UiNotification>>(emptyList())
    val notifications: StateFlow<List<UiNotification>> = _notifications.asStateFlow()

    init {
        // Auto-seed database with KVS preset data if empty
        viewModelScope.launch {
            val existingClasses = dao.getAllClassesList()
            if (existingClasses.isEmpty()) {
                seedDefaultKvsData()
            }
        }
    }

    fun seedDefaultKvsData() {
        viewModelScope.launch {
            _generationStatusText.value = "Loading KVS Standard Preset..."
            dao.insertSchoolSettings(KvsPresetData.getDefaultSchoolSettings())
            dao.insertTeachers(KvsPresetData.getDefaultTeachers())
            dao.insertClasses(KvsPresetData.getDefaultClasses())
            dao.insertSubjects(KvsPresetData.getDefaultSubjects())
            dao.insertPeriods(KvsPresetData.getDefaultPeriods())
            dao.insertRooms(KvsPresetData.getDefaultRooms())

            // Log upload doc preset
            dao.insertUploadDoc(
                UploadDocEntity(
                    docName = "KVS_Primary_Timetable_Guidelines_2026.pdf",
                    docType = "KVS_GUIDELINE",
                    uploadDate = "Today",
                    summaryText = "Extracted 36 weekly periods rule, PRT max 6 periods/day, morning prayer fixed, lunch fixed."
                )
            )

            // Generate initial timetable
            generateTimetableWithAi()
            addNotification("Preset Loaded", "Loaded official KVS Primary Section dataset and generated initial timetable.", "SUCCESS")
        }
    }

    fun generateTimetableWithAi() {
        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgress.value = 0.1f
            _generationStatusText.value = "Reading KVS Guidelines & Uploaded Documents..."

            kotlinx.coroutines.delay(400)
            _generationProgress.value = 0.35f
            _generationStatusText.value = "Extracting Teacher & Subject Constraints..."

            kotlinx.coroutines.delay(400)
            _generationProgress.value = 0.65f
            _generationStatusText.value = "Running Backtracking Constraint Optimization Engine..."

            val currentClasses = dao.getAllClassesList()
            val currentTeachers = dao.getAllTeachersList()
            val currentSubjects = dao.getAllSubjectsList()
            val currentPeriods = dao.getAllPeriodsList()
            val currentRooms = dao.getAllRooms() .firstOrNull() ?: emptyList()

            val result = TimetableGeneratorEngine.generateCompleteTimetable(
                classes = currentClasses,
                teachers = currentTeachers,
                subjects = currentSubjects,
                periods = currentPeriods,
                rooms = currentRooms
            )

            _generationProgress.value = 0.90f
            _generationStatusText.value = "Saving Conflict-Free Schedule to Database..."

            dao.clearTimetable()
            dao.insertTimetableSlots(result.slots)

            _generationProgress.value = 1.0f
            _isGenerating.value = false
            _generationStatusText.value = "Timetable Generation Complete!"

            addNotification(
                title = "Timetable Generated",
                message = "Successfully created ${result.totalSlotsGenerated} slots in ${result.executionTimeMs}ms with ${result.conflictCount} conflicts.",
                type = if (result.conflictCount == 0) "SUCCESS" else "WARNING"
            )
        }
    }

    fun toggleTeacherAbsence(teacherId: Long, isAbsent: Boolean) {
        viewModelScope.launch {
            val list = dao.getAllTeachersList()
            val teacher = list.find { it.id == teacherId }
            if (teacher != null) {
                val updated = teacher.copy(isAbsentToday = isAbsent)
                dao.updateTeacher(updated)
                addNotification(
                    title = "Teacher Status Changed",
                    message = "${teacher.name} marked as ${if (isAbsent) "ABSENT" else "ACTIVE"}.",
                    type = if (isAbsent) "WARNING" else "INFO"
                )
            }
        }
    }

    fun autoSuggestAndAssignSubstitute(absentTeacherName: String, periodNo: Int, className: String, section: String) {
        viewModelScope.launch {
            val activePrts = dao.getAllTeachersList().filter { !it.isAbsentToday }
            val currentSlots = dao.getAllTimetableSlotsList()

            // Find free active teachers at this period
            val busyTeacherNames = currentSlots.filter { it.periodNo == periodNo && it.dayOfWeek == "MONDAY" }.map { it.teacherName }.toSet()
            val freeTeachers = activePrts.filter { !busyTeacherNames.contains(it.name) }

            val substitute = freeTeachers.firstOrNull() ?: activePrts.firstOrNull()

            if (substitute != null) {
                dao.insertSubstitution(
                    SubstitutionEntity(
                        dateString = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                        periodNo = periodNo,
                        className = className,
                        section = section,
                        absentTeacherName = absentTeacherName,
                        substituteTeacherId = substitute.id,
                        substituteTeacherName = substitute.name,
                        subjectName = "Arrangement / " + substitute.primarySubject,
                        status = "ASSIGNED"
                    )
                )

                addNotification(
                    title = "Substitute Assigned",
                    message = "${substitute.name} assigned to $className-$section for Period $periodNo (Replacing $absentTeacherName).",
                    type = "SUCCESS"
                )
            }
        }
    }

    fun handleSimulatedDocUpload(docName: String, docType: String, fileContent: String) {
        viewModelScope.launch {
            val rules = KvsGuidelineParser.parseGuidelineText(fileContent)
            dao.insertUploadDoc(
                UploadDocEntity(
                    docName = docName,
                    docType = docType,
                    uploadDate = "Just now",
                    summaryText = "Extracted ${rules.totalWeeklyPeriods} weekly periods rule, subject distribution & PRT constraints."
                )
            )

            if (docType == "TEACHER_EXCEL") {
                val parsedTeachers = KvsGuidelineParser.parseTeacherExcelContent(fileContent)
                if (parsedTeachers.isNotEmpty()) {
                    val newTeachers = parsedTeachers.mapIndexed { idx, map ->
                        TeacherEntity(
                            name = map["Name"] ?: "Teacher $idx",
                            empId = map["EmpID"] ?: "EMP-$idx",
                            designation = map["Designation"] ?: "PRT",
                            primarySubject = map["Subject"] ?: "General"
                        )
                    }
                    dao.insertTeachers(newTeachers)
                }
            }

            addNotification("File Uploaded", "Processed $docName successfully.", "SUCCESS")
        }
    }

    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return
        val userMsg = ChatMessage(sender = "User", text = userText)
        _chatMessages.value = _chatMessages.value + userMsg
        _isChatLoading.value = true

        viewModelScope.launch {
            val totalT = dao.getAllTeachersList().size
            val totalC = dao.getAllClassesList().size
            val contextInfo = "$totalT PRT Teachers, $totalC Classes, KVS Primary Section"

            val responseText = GeminiChatService.askGeminiAssistant(userText, contextInfo)

            _chatMessages.value = _chatMessages.value + ChatMessage(sender = "EduBell AI", text = responseText)
            _isChatLoading.value = false
        }
    }

    fun addNotification(title: String, message: String, type: String = "INFO") {
        val notif = UiNotification(title = title, message = message, type = type)
        _notifications.value = listOf(notif) + _notifications.value
    }

    fun dismissNotification(id: String) {
        _notifications.value = _notifications.value.filter { it.id != id }
    }

    fun addTeacher(teacher: TeacherEntity) {
        viewModelScope.launch {
            dao.insertTeacher(teacher)
            addNotification("Teacher Added", "${teacher.name} added to Teacher Master.", "SUCCESS")
        }
    }

    fun addClass(classEntity: ClassEntity) {
        viewModelScope.launch {
            dao.insertClass(classEntity)
            addNotification("Class Added", "${classEntity.className}-${classEntity.section} added.", "SUCCESS")
        }
    }

    fun addSubject(subjectEntity: SubjectEntity) {
        viewModelScope.launch {
            dao.insertSubject(subjectEntity)
            addNotification("Subject Added", "${subjectEntity.name} added.", "SUCCESS")
        }
    }
}
