package com.example.engine

import com.example.data.local.*
import kotlin.random.Random

object TimetableGeneratorEngine {

    data class GenerationResult(
        val slots: List<TimetableSlotEntity>,
        val conflictCount: Int,
        val totalSlotsGenerated: Int,
        val executionTimeMs: Long,
        val reportSummary: String
    )

    fun generateCompleteTimetable(
        classes: List<ClassEntity>,
        teachers: List<TeacherEntity>,
        subjects: List<SubjectEntity>,
        periods: List<PeriodMasterEntity>,
        rooms: List<RoomEntity>
    ): GenerationResult {
        val startTime = System.currentTimeMillis()

        val workingDays = listOf("MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY")
        val teachingPeriods = periods.filter { it.periodType == "TEACHING" }.map { it.periodNo }

        // Map teacher primary subjects for auto-assignment
        val subjectTeacherMap = mutableMapOf<String, MutableList<TeacherEntity>>()
        teachers.forEach { teacher ->
            val subjName = teacher.primarySubject
            subjectTeacherMap.getOrPut(subjName) { mutableListOf() }.add(teacher)
        }

        // Active teachers only
        val activeTeachers = teachers.filter { !it.isAbsentToday }

        val generatedSlots = mutableListOf<TimetableSlotEntity>()
        var conflictCount = 0

        // Track occupied teacher periods: key = "DAY_PERIOD_TEACHER_ID"
        val teacherSchedule = mutableSetOf<String>()
        // Track occupied class periods: key = "DAY_PERIOD_CLASS_ID"
        val classSchedule = mutableSetOf<String>()
        // Track teacher daily period count: key = "DAY_TEACHER_ID" -> Int
        val teacherDailyCount = mutableMapOf<String, Int>()

        // 1. First, insert Fixed Morning Assembly and Lunch Break for all classes
        classes.forEach { classObj ->
            workingDays.forEach { day ->
                // Assembly (Period 0)
                generatedSlots.add(
                    TimetableSlotEntity(
                        dayOfWeek = day,
                        periodNo = 0,
                        classId = classObj.id,
                        className = classObj.className,
                        section = classObj.section,
                        subjectId = -1,
                        subjectName = "Morning Assembly & Prayer",
                        teacherId = -1,
                        teacherName = classObj.classTeacherName.ifEmpty { "Class Teacher" },
                        roomName = "School Assembly Ground",
                        isFixed = true
                    )
                )

                // Lunch Break (Period 5)
                generatedSlots.add(
                    TimetableSlotEntity(
                        dayOfWeek = day,
                        periodNo = 5,
                        classId = classObj.id,
                        className = classObj.className,
                        section = classObj.section,
                        subjectId = -2,
                        subjectName = "Recess / Lunch Break",
                        teacherId = -1,
                        teacherName = "On Duty PRT",
                        roomName = classObj.roomNo,
                        isFixed = true
                    )
                )
            }
        }

        // 2. Generate Teaching Slots (Periods 1, 2, 3, 4, 6, 7, 8) across 6 working days
        // Total available teaching slots per class = 6 days * 7 periods = 42 slots
        classes.forEach { classObj ->
            // Prepare required subject bucket for 1 week based on KVS Guidelines
            val subjectRequirement = mutableListOf<SubjectEntity>()
            subjects.forEach { subject ->
                val count = if (subject.weeklyPeriods > 0) subject.weeklyPeriods else 1
                repeat(count) {
                    subjectRequirement.add(subject)
                }
            }

            // Shuffle for natural distribution across days
            subjectRequirement.shuffle(Random(classObj.id.toInt() + 42))

            var reqIndex = 0

            workingDays.forEach { day ->
                teachingPeriods.forEach { period ->
                    if (reqIndex < subjectRequirement.size) {
                        val currentSubject = subjectRequirement[reqIndex]

                        // Find best available PRT teacher for this subject
                        val candidateTeachers = subjectTeacherMap[currentSubject.name]
                            ?.filter { !it.isAbsentToday }
                            ?: activeTeachers

                        var assignedTeacher: TeacherEntity? = null
                        var hasConflict = false
                        var conflictMsg = ""

                        // Search for un-clashed teacher
                        for (teacher in candidateTeachers) {
                            val teacherKey = "${day}_${period}_${teacher.id}"
                            val dailyCountKey = "${day}_${teacher.id}"
                            val currentDailyLoad = teacherDailyCount.getOrDefault(dailyCountKey, 0)

                            if (!teacherSchedule.contains(teacherKey) && currentDailyLoad < teacher.maxDailyPeriods) {
                                assignedTeacher = teacher
                                teacherSchedule.add(teacherKey)
                                teacherDailyCount[dailyCountKey] = currentDailyLoad + 1
                                break
                            }
                        }

                        // Fallback if all specialized teachers clashed: pick any active free PRT
                        if (assignedTeacher == null) {
                            for (teacher in activeTeachers) {
                                val teacherKey = "${day}_${period}_${teacher.id}"
                                val dailyCountKey = "${day}_${teacher.id}"
                                val currentDailyLoad = teacherDailyCount.getOrDefault(dailyCountKey, 0)

                                if (!teacherSchedule.contains(teacherKey) && currentDailyLoad < teacher.maxDailyPeriods) {
                                    assignedTeacher = teacher
                                    teacherSchedule.add(teacherKey)
                                    teacherDailyCount[dailyCountKey] = currentDailyLoad + 1
                                    break
                                }
                            }
                        }

                        // If still null, assign primary class teacher with conflict flag
                        if (assignedTeacher == null) {
                            val fallbackTeacher = activeTeachers.firstOrNull() ?: TeacherEntity(name = "Assigned PRT", empId = "000", designation = "PRT", primarySubject = currentSubject.name)
                            assignedTeacher = fallbackTeacher
                            hasConflict = true
                            conflictMsg = "Potential teacher overload or shift clash in Period $period"
                            conflictCount++
                        }

                        val roomName = when (currentSubject.code) {
                            "MUS" -> "Music Room"
                            "ART" -> "Art & Craft Room"
                            "CMP" -> "Computer Lab"
                            "LIB" -> "Primary Library"
                            "GAM" -> "Playground"
                            else -> classObj.roomNo
                        }

                        generatedSlots.add(
                            TimetableSlotEntity(
                                dayOfWeek = day,
                                periodNo = period,
                                classId = classObj.id,
                                className = classObj.className,
                                section = classObj.section,
                                subjectId = currentSubject.id,
                                subjectName = currentSubject.name,
                                teacherId = assignedTeacher.id,
                                teacherName = assignedTeacher.name,
                                roomName = roomName,
                                isConflict = hasConflict,
                                conflictNote = conflictMsg
                            )
                        )

                        reqIndex++
                    } else {
                        // Fill extra slot with Revision / Reading
                        generatedSlots.add(
                            TimetableSlotEntity(
                                dayOfWeek = day,
                                periodNo = period,
                                classId = classObj.id,
                                className = classObj.className,
                                section = classObj.section,
                                subjectId = -3,
                                subjectName = "Revision & Activity",
                                teacherId = -1,
                                teacherName = classObj.classTeacherName.ifEmpty { "PRT" },
                                roomName = classObj.roomNo
                            )
                        )
                    }
                }
            }
        }

        val endTime = System.currentTimeMillis()
        val duration = endTime - startTime

        val summary = "Successfully generated ${generatedSlots.size} timetable slots across ${classes.size} sections. " +
                "Applied KVS Primary Guidelines (Hindi: 6, Eng: 6, Maths: 6, EVS: 5, Art: 3, Music: 3, Games: 3, Lib: 1, CMP: 2, WorkEdu: 1). " +
                "Detected $conflictCount conflicts."

        return GenerationResult(
            slots = generatedSlots,
            conflictCount = conflictCount,
            totalSlotsGenerated = generatedSlots.size,
            executionTimeMs = duration,
            reportSummary = summary
        )
    }
}
