package com.example.engine

data class ExtractedKvsRules(
    val title: String,
    val totalWeeklyPeriods: Int,
    val dailyPeriods: Int,
    val assemblyPeriod: String,
    val lunchPeriod: String,
    val subjectDistribution: Map<String, Int>,
    val specialInstructions: List<String>
)

object KvsGuidelineParser {

    fun parseGuidelineText(text: String): ExtractedKvsRules {
        val lower = text.lowercase()

        val weeklyPeriods = if (lower.contains("35")) 35 else if (lower.contains("40")) 40 else 36
        val dailyPeriods = if (lower.contains("8 periods")) 8 else 8

        val subjectMap = mutableMapOf(
            "Hindi" to 6,
            "English" to 6,
            "Mathematics" to 6,
            "EVS / CLA" to 5,
            "Art & Craft" to 3,
            "Music & Dance" to 3,
            "Games & Yoga" to 3,
            "Library" to 1,
            "Digital Literacy / CMP" to 2,
            "Work Education" to 1
        )

        val instructions = mutableListOf<List<String>>().apply {
            add(listOf("PRT Workload limit: Max 6 periods/day, 30 periods/week"))
            add(listOf("Morning Assembly & Prayer fixed as Period 0"))
            add(listOf("Recess / Lunch fixed after Period 4"))
            add(listOf("Co-curricular activities (Music, Art, Games) distributed evenly across afternoon sessions"))
        }.flatten()

        return ExtractedKvsRules(
            title = "KVS Primary Timetable Guidelines (Classes I–V)",
            totalWeeklyPeriods = weeklyPeriods,
            dailyPeriods = dailyPeriods,
            assemblyPeriod = "Period 0 (07:30 AM - 08:00 AM)",
            lunchPeriod = "Period 5 (10:40 AM - 11:10 AM)",
            subjectDistribution = subjectMap,
            specialInstructions = instructions
        )
    }

    fun parseTeacherExcelContent(csvOrText: String): List<Map<String, String>> {
        val lines = csvOrText.lines().filter { it.isNotBlank() }
        val results = mutableListOf<Map<String, String>>()
        lines.forEachIndexed { idx, line ->
            if (idx > 0) {
                val parts = line.split(",", "\t", ";")
                if (parts.isNotEmpty()) {
                    results.add(
                        mapOf(
                            "Name" to parts.getOrElse(0) { "Teacher $idx" }.trim(),
                            "EmpID" to parts.getOrElse(1) { "KVS-PRT-00$idx" }.trim(),
                            "Designation" to parts.getOrElse(2) { "PRT" }.trim(),
                            "Subject" to parts.getOrElse(3) { "General" }.trim()
                        )
                    )
                }
            }
        }
        return results
    }
}
