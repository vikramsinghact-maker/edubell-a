package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EduBellDao {

    // School Settings
    @Query("SELECT * FROM school_settings WHERE id = 1")
    fun getSchoolSettings(): Flow<SchoolSettingsEntity?>

    @Query("SELECT * FROM school_settings WHERE id = 1")
    suspend fun getSchoolSettingsDirect(): SchoolSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchoolSettings(settings: SchoolSettingsEntity)

    // Teachers
    @Query("SELECT * FROM teachers ORDER BY name ASC")
    fun getAllTeachers(): Flow<List<TeacherEntity>>

    @Query("SELECT * FROM teachers WHERE isAbsentToday = 0 ORDER BY name ASC")
    fun getActiveTeachers(): Flow<List<TeacherEntity>>

    @Query("SELECT * FROM teachers ORDER BY name ASC")
    suspend fun getAllTeachersList(): List<TeacherEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: TeacherEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(teachers: List<TeacherEntity>)

    @Update
    suspend fun updateTeacher(teacher: TeacherEntity)

    @Delete
    suspend fun deleteTeacher(teacher: TeacherEntity)

    @Query("DELETE FROM teachers")
    suspend fun clearTeachers()

    // Classes
    @Query("SELECT * FROM classes ORDER BY className ASC, section ASC")
    fun getAllClasses(): Flow<List<ClassEntity>>

    @Query("SELECT * FROM classes ORDER BY className ASC, section ASC")
    suspend fun getAllClassesList(): List<ClassEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(classEntity: ClassEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<ClassEntity>)

    @Delete
    suspend fun deleteClass(classEntity: ClassEntity)

    @Query("DELETE FROM classes")
    suspend fun clearClasses()

    // Subjects
    @Query("SELECT * FROM subjects ORDER BY priority DESC, name ASC")
    fun getAllSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects ORDER BY priority DESC, name ASC")
    suspend fun getAllSubjectsList(): List<SubjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Delete
    suspend fun deleteSubject(subject: SubjectEntity)

    @Query("DELETE FROM subjects")
    suspend fun clearSubjects()

    // Rooms
    @Query("SELECT * FROM rooms ORDER BY name ASC")
    fun getAllRooms(): Flow<List<RoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<RoomEntity>)

    // Periods
    @Query("SELECT * FROM period_masters ORDER BY periodNo ASC")
    fun getAllPeriods(): Flow<List<PeriodMasterEntity>>

    @Query("SELECT * FROM period_masters ORDER BY periodNo ASC")
    suspend fun getAllPeriodsList(): List<PeriodMasterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPeriods(periods: List<PeriodMasterEntity>)

    // Timetable Slots
    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek ASC, periodNo ASC")
    fun getAllTimetableSlots(): Flow<List<TimetableSlotEntity>>

    @Query("SELECT * FROM timetable_slots ORDER BY dayOfWeek ASC, periodNo ASC")
    suspend fun getAllTimetableSlotsList(): List<TimetableSlotEntity>

    @Query("SELECT * FROM timetable_slots WHERE className = :className AND section = :section ORDER BY dayOfWeek ASC, periodNo ASC")
    fun getTimetableForClass(className: String, section: String): Flow<List<TimetableSlotEntity>>

    @Query("SELECT * FROM timetable_slots WHERE teacherName = :teacherName ORDER BY dayOfWeek ASC, periodNo ASC")
    fun getTimetableForTeacher(teacherName: String): Flow<List<TimetableSlotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimetableSlots(slots: List<TimetableSlotEntity>)

    @Query("DELETE FROM timetable_slots")
    suspend fun clearTimetable()

    @Update
    suspend fun updateTimetableSlot(slot: TimetableSlotEntity)

    // Substitutions
    @Query("SELECT * FROM substitutions ORDER BY id DESC")
    fun getAllSubstitutions(): Flow<List<SubstitutionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubstitution(substitution: SubstitutionEntity)

    // Uploaded Documents
    @Query("SELECT * FROM upload_docs ORDER BY id DESC")
    fun getAllUploadDocs(): Flow<List<UploadDocEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadDoc(doc: UploadDocEntity)
}
