package com.example.data

import com.example.data.local.*

object KvsPresetData {

    fun getDefaultSchoolSettings() = SchoolSettingsEntity(
        id = 1,
        schoolName = "Kendriya Vidyalaya No. 1 Cantt",
        kvRegion = "Delhi Region",
        section = "Primary Section (Classes I - V)",
        principalName = "Dr. S. K. Sharma",
        headmasterName = "Mrs. Sunita Verma",
        shiftType = "Single Shift (07:30 AM - 01:40 PM)",
        totalDailyPeriods = 8,
        workingDays = "Monday,Tuesday,Wednesday,Thursday,Friday,Saturday",
        academicYear = "2026-2027"
    )

    fun getDefaultTeachers(): List<TeacherEntity> {
        return listOf(
            TeacherEntity(name = "Mrs. Sunita Verma", empId = "KVS-PRT-001", designation = "Headmaster / PRT", primarySubject = "Hindi", maxDailyPeriods = 4, maxWeeklyPeriods = 20),
            TeacherEntity(name = "Mr. Rahul Sharma", empId = "KVS-PRT-002", designation = "PRT", primarySubject = "Mathematics", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Ms. Priya Singh", empId = "KVS-PRT-003", designation = "PRT", primarySubject = "English", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Mrs. Anjali Gupta", empId = "KVS-PRT-004", designation = "PRT", primarySubject = "EVS / CLA", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Mr. Ramesh Kumar", empId = "KVS-PRT-005", designation = "PRT", primarySubject = "Hindi", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Ms. Meena Patel", empId = "KVS-PRT-006", designation = "PRT", primarySubject = "Mathematics", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Mr. Vijay Singh", empId = "KVS-PRT-007", designation = "PRT", primarySubject = "English", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Mrs. Kavita Roy", empId = "KVS-PRT-008", designation = "PRT", primarySubject = "EVS / CLA", maxDailyPeriods = 6, maxWeeklyPeriods = 30),
            TeacherEntity(name = "Mr. Rajesh Saxena", empId = "KVS-PRT-009", designation = "PRT Music", primarySubject = "Music & Dance", maxDailyPeriods = 6, maxWeeklyPeriods = 28),
            TeacherEntity(name = "Ms. Deepa Nair", empId = "KVS-PRT-010", designation = "PRT Art", primarySubject = "Art & Craft", maxDailyPeriods = 6, maxWeeklyPeriods = 28),
            TeacherEntity(name = "Mr. Alok Tiwari", empId = "KVS-PRT-011", designation = "PRT PET", primarySubject = "Games & Yoga", maxDailyPeriods = 6, maxWeeklyPeriods = 28),
            TeacherEntity(name = "Mrs. Rekha Joshi", empId = "KVS-PRT-012", designation = "PRT Library", primarySubject = "Library", maxDailyPeriods = 5, maxWeeklyPeriods = 24),
            TeacherEntity(name = "Mr. Sanjay Mishra", empId = "KVS-PRT-013", designation = "PRT Computer", primarySubject = "Digital Literacy / CMP", maxDailyPeriods = 5, maxWeeklyPeriods = 24)
        )
    }

    fun getDefaultClasses(): List<ClassEntity> {
        return listOf(
            ClassEntity(className = "Class I", section = "A", roomNo = "R-101", strength = 40, classTeacherName = "Mrs. Sunita Verma"),
            ClassEntity(className = "Class I", section = "B", roomNo = "R-102", strength = 40, classTeacherName = "Mr. Ramesh Kumar"),
            ClassEntity(className = "Class II", section = "A", roomNo = "R-103", strength = 40, classTeacherName = "Ms. Priya Singh"),
            ClassEntity(className = "Class II", section = "B", roomNo = "R-104", strength = 40, classTeacherName = "Mr. Vijay Singh"),
            ClassEntity(className = "Class III", section = "A", roomNo = "R-105", strength = 40, classTeacherName = "Mr. Rahul Sharma"),
            ClassEntity(className = "Class III", section = "B", roomNo = "R-106", strength = 40, classTeacherName = "Ms. Meena Patel"),
            ClassEntity(className = "Class IV", section = "A", roomNo = "R-107", strength = 40, classTeacherName = "Mrs. Anjali Gupta"),
            ClassEntity(className = "Class IV", section = "B", roomNo = "R-108", strength = 40, classTeacherName = "Mrs. Kavita Roy"),
            ClassEntity(className = "Class V", section = "A", roomNo = "R-109", strength = 40, classTeacherName = "Mr. Rahul Sharma"),
            ClassEntity(className = "Class V", section = "B", roomNo = "R-110", strength = 40, classTeacherName = "Ms. Priya Singh")
        )
    }

    fun getDefaultSubjects(): List<SubjectEntity> {
        return listOf(
            SubjectEntity(name = "Hindi", code = "HIN", applicableClasses = "Class I-V", weeklyPeriods = 6, dailyMax = 1, priority = 5, colorHex = "#E11D48"),
            SubjectEntity(name = "English", code = "ENG", applicableClasses = "Class I-V", weeklyPeriods = 6, dailyMax = 1, priority = 5, colorHex = "#2563EB"),
            SubjectEntity(name = "Mathematics", code = "MAT", applicableClasses = "Class I-V", weeklyPeriods = 6, dailyMax = 1, priority = 5, colorHex = "#D97706"),
            SubjectEntity(name = "EVS / CLA", code = "EVS", applicableClasses = "Class I-V", weeklyPeriods = 5, dailyMax = 1, priority = 4, colorHex = "#059669"),
            SubjectEntity(name = "Art & Craft", code = "ART", applicableClasses = "Class I-V", weeklyPeriods = 3, dailyMax = 1, priority = 2, colorHex = "#7C3AED"),
            SubjectEntity(name = "Music & Dance", code = "MUS", applicableClasses = "Class I-V", weeklyPeriods = 3, dailyMax = 1, priority = 2, colorHex = "#DB2777"),
            SubjectEntity(name = "Games & Yoga", code = "GAM", applicableClasses = "Class I-V", weeklyPeriods = 3, dailyMax = 1, priority = 2, colorHex = "#0284C7"),
            SubjectEntity(name = "Library", code = "LIB", applicableClasses = "Class I-V", weeklyPeriods = 1, dailyMax = 1, priority = 1, colorHex = "#4F46E5"),
            SubjectEntity(name = "Digital Literacy / CMP", code = "CMP", applicableClasses = "Class I-V", weeklyPeriods = 2, dailyMax = 1, priority = 2, colorHex = "#0D9488"),
            SubjectEntity(name = "Work Education", code = "WED", applicableClasses = "Class I-V", weeklyPeriods = 1, dailyMax = 1, priority = 1, colorHex = "#854D0E")
        )
    }

    fun getDefaultPeriods(): List<PeriodMasterEntity> {
        return listOf(
            PeriodMasterEntity(periodNo = 0, name = "Morning Assembly & Prayer", startTime = "07:30 AM", endTime = "08:00 AM", periodType = "ASSEMBLY"),
            PeriodMasterEntity(periodNo = 1, name = "Period 1", startTime = "08:00 AM", endTime = "08:40 AM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 2, name = "Period 2", startTime = "08:40 AM", endTime = "09:20 AM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 3, name = "Period 3", startTime = "09:20 AM", endTime = "10:00 AM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 4, name = "Period 4", startTime = "10:00 AM", endTime = "10:40 AM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 5, name = "Recess / Lunch Break", startTime = "10:40 AM", endTime = "11:10 AM", periodType = "LUNCH"),
            PeriodMasterEntity(periodNo = 6, name = "Period 5", startTime = "11:10 AM", endTime = "11:50 AM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 7, name = "Period 6", startTime = "11:50 AM", endTime = "12:30 PM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 8, name = "Period 7", startTime = "12:30 PM", endTime = "01:10 PM", periodType = "TEACHING"),
            PeriodMasterEntity(periodNo = 9, name = "Period 8", startTime = "01:10 PM", endTime = "01:40 PM", periodType = "TEACHING")
        )
    }

    fun getDefaultRooms(): List<RoomEntity> {
        return listOf(
            RoomEntity(name = "R-101 (Class I-A)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-102 (Class I-B)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-103 (Class II-A)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-104 (Class II-B)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-105 (Class III-A)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-106 (Class III-B)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-107 (Class IV-A)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-108 (Class IV-B)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-109 (Class V-A)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "R-110 (Class V-B)", capacity = 40, roomType = "Classroom"),
            RoomEntity(name = "Music & Dance Room", capacity = 45, roomType = "Special Room"),
            RoomEntity(name = "Art & Craft Room", capacity = 45, roomType = "Special Room"),
            RoomEntity(name = "Primary Computer Lab", capacity = 40, roomType = "Special Room"),
            RoomEntity(name = "Primary Library", capacity = 50, roomType = "Special Room"),
            RoomEntity(name = "Playground / Sports Field", capacity = 100, roomType = "Outdoor")
        )
    }
}
