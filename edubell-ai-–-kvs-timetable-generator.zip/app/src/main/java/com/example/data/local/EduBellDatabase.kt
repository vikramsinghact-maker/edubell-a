package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SchoolSettingsEntity::class,
        TeacherEntity::class,
        ClassEntity::class,
        SubjectEntity::class,
        RoomEntity::class,
        PeriodMasterEntity::class,
        TimetableSlotEntity::class,
        SubstitutionEntity::class,
        UploadDocEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class EduBellDatabase : RoomDatabase() {

    abstract fun edubellDao(): EduBellDao

    companion object {
        @Volatile
        private var INSTANCE: EduBellDatabase? = null

        fun getDatabase(context: Context): EduBellDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EduBellDatabase::class.java,
                    "edubell_kvs_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
