package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "school_settings")
data class SchoolSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val schoolName: String = "Kendriya Vidyalaya No. 1 Cantt",
    val kvRegion: String = "Delhi Region",
    val section: String = "Primary Section (Classes I - V)",
    val principalName: String = "Dr. S. K. Sharma",
    val headmasterName: String = "Mrs. Sunita Verma",
    val shiftType: String = "Single Shift (07:30 AM - 01:40 PM)",
    val totalDailyPeriods: Int = 8,
    val workingDays: String = "Monday,Tuesday,Wednesday,Thursday,Friday,Saturday",
    val academicYear: String = "2026-2027"
)

@Entity(tableName = "teachers")
data class TeacherEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val empId: String,
    val designation: String, // PRT, PRT Music, PRT Art, TGT, Headmaster
    val primarySubject: String,
    val maxDailyPeriods: Int = 6,
    val maxWeeklyPeriods: Int = 30,
    val preferredFreePeriod: Int = 5,
    val isAbsentToday: Boolean = false,
    val status: String = "Active",
    val phone: String = "+91 9876543210",
    val email: String = ""
)

@Entity(tableName = "classes")
data class ClassEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val className: String, // Class I, Class II, Class III, Class IV, Class V
    val section: String, // A, B, C
    val roomNo: String,
    val strength: Int = 40,
    val classTeacherName: String = ""
)

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // Hindi, English, Mathematics, EVS/CLA, Art & Craft, Music & Dance, Games & Yoga, Library, Digital Literacy/CMP, Work Education
    val code: String,
    val applicableClasses: String = "Class I-V",
    val weeklyPeriods: Int = 6,
    val dailyMax: Int = 1,
    val priority: Int = 1,
    val colorHex: String = "#2563EB"
)

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // Room 101, Music Room, Art Room, Computer Lab, Playground, Library
    val capacity: Int = 45,
    val roomType: String = "General Classroom" // Classroom, Special Lab, Activity Room, Outdoor
)

@Entity(tableName = "period_masters")
data class PeriodMasterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val periodNo: Int, // 0 = Morning Assembly, 1 to 8, 9 = Lunch
    val name: String,
    val startTime: String,
    val endTime: String,
    val periodType: String // ASSEMBLY, TEACHING, LUNCH, SHORT_BREAK
)

@Entity(tableName = "timetable_slots")
data class TimetableSlotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayOfWeek: String, // MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
    val periodNo: Int,
    val classId: Long,
    val className: String,
    val section: String,
    val subjectId: Long,
    val subjectName: String,
    val teacherId: Long,
    val teacherName: String,
    val roomName: String,
    val isFixed: Boolean = false,
    val isConflict: Boolean = false,
    val conflictNote: String = ""
)

@Entity(tableName = "substitutions")
data class SubstitutionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val periodNo: Int,
    val className: String,
    val section: String,
    val absentTeacherName: String,
    val substituteTeacherId: Long,
    val substituteTeacherName: String,
    val subjectName: String,
    val status: String = "ASSIGNED"
)

@Entity(tableName = "upload_docs")
data class UploadDocEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val docName: String,
    val docType: String, // KVS_GUIDELINE, TEACHER_EXCEL, CLASS_EXCEL, SUBJECT_EXCEL, BELL_EXCEL
    val uploadDate: String,
    val summaryText: String,
    val status: String = "PROCESSED"
)
